# COP4600 - Program \#2
### Group \#66

To compile and execute the included testfile (`testchar.c`), run the included scripts, `./run`.
If you wish to make your own testfile, name is `testchar.c` and have it access the driver at `/dev/copchar`