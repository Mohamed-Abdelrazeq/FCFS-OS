#ifndef fcfs_h
#define fcfs_h

#include <stdio.h>
struct testcase;

//Function Prototypes
void fcfs(struct testcase);

#endif
