#ifndef sjf_h
#define sjf_h

#include <stdio.h>
struct testcase;
//Function Prototypes
void sjf(struct testcase);

#endif
