#ifndef rr_h
#define rr_h

#include <stdio.h>

struct testcase;
void rr(struct testcase);

#endif
